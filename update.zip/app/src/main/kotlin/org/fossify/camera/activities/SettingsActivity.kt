package org.fossify.camera.activities

import android.annotation.SuppressLint
import android.os.Bundle
import org.fossify.camera.BuildConfig
import org.fossify.camera.R
import org.fossify.camera.databinding.ActivitySettingsBinding
import org.fossify.camera.extensions.checkLocationPermission
import org.fossify.camera.extensions.config
import org.fossify.camera.helpers.Config
import org.fossify.camera.models.CaptureMode
import org.fossify.commons.dialogs.*
import org.fossify.commons.extensions.*
import org.fossify.commons.helpers.*
import org.fossify.commons.models.FAQItem
import org.fossify.commons.models.RadioItem
import java.util.*
import kotlin.system.exitProcess

class SettingsActivity : SimpleActivity() {
    private val binding by viewBinding(ActivitySettingsBinding::inflate)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding.apply {
            setContentView(root)
            setupOptionsMenu()
            refreshMenuItems()

            setupEdgeToEdge(padBottomSystem = listOf(settingsNestedScrollview))
            setupMaterialScrollListener(binding.settingsNestedScrollview, binding.settingsAppbar)
        }
    }

    override fun onResume() {
        super.onResume()
        setupTopAppBar(binding.settingsAppbar, NavigationIcon.Arrow)

        setupCustomizeColors()
        setupUseEnglish()
        setupLanguage()
        setupSound()
        setupVolumeButtonsAsShutter()
        setupMaxBrightness()
        setupFlipPhotos()
        setupSavePhotoMetadata()
        setupSavePhotoVideoLocation()
        setupSavePhotosFolder()
        setupPhotoQuality()
        setupCaptureMode()
        setupVideoFormat()
        setupRememberLens()
        setupGridLines()
        setupPhotoFormat()
        setupHeicQuality()
        setupStartMax()
        setupQr()
        setupSwipeCamera()
        updateTextColors(binding.settingsHolder)

        val properPrimaryColor = getProperPrimaryColor()
        binding.apply {
            arrayListOf(
                settingsColorCustomizationLabel,
                settingsGeneralSettingsLabel,
                settingsCameraLabel,
                settingsSavingLabel,
            ).forEach {
                it.setTextColor(properPrimaryColor)
            }
        }
    }

    private fun refreshMenuItems() {
        binding.settingsToolbar.menu.apply {
            findItem(R.id.more_apps_from_us).isVisible =
                resources.getBoolean(org.fossify.commons.R.bool.is_google_play_build)
        }
    }

    private fun setupOptionsMenu() {
        binding.settingsToolbar.setOnMenuItemClickListener { menuItem ->
            when (menuItem.itemId) {
                R.id.more_apps_from_us -> launchMoreAppsFromUsIntent()
                R.id.about -> launchAbout()
                else -> return@setOnMenuItemClickListener false
            }
            return@setOnMenuItemClickListener true
        }
    }

    private fun setupCustomizeColors() {
        binding.settingsColorCustomizationHolder.setOnClickListener {
            startCustomizationActivity()
        }
    }

    private fun setupUseEnglish() = binding.apply {
        settingsUseEnglishHolder.beVisibleIf((config.wasUseEnglishToggled || Locale.getDefault().language != "en") && !isTiramisuPlus())
        settingsUseEnglish.isChecked = config.useEnglish
        settingsUseEnglishHolder.setOnClickListener {
            settingsUseEnglish.toggle()
            config.useEnglish = settingsUseEnglish.isChecked
            exitProcess(0)
        }
    }

    private fun setupLanguage() = binding.apply {
        settingsLanguage.text = Locale.getDefault().displayLanguage
        settingsLanguageHolder.beVisibleIf(isTiramisuPlus())

        listOf(settingsGeneralSettingsHolder, settingsGeneralSettingsLabel).forEach {
            it.beGoneIf(settingsUseEnglishHolder.isGone() && settingsPurchaseThankYouHolder.isGone() && settingsLanguageHolder.isGone())
        }

        settingsLanguageHolder.setOnClickListener {
            launchChangeAppLanguageIntent()
        }
    }

    private fun launchAbout() {
        val licenses = LICENSE_GLIDE

        val faqItems = arrayListOf(
            FAQItem(R.string.faq_1_title, R.string.faq_1_text)
        )

        if (resources.getBoolean(org.fossify.commons.R.bool.is_google_play_build)) {
            faqItems.add(
                FAQItem(
                    org.fossify.commons.R.string.faq_2_title_commons,
                    org.fossify.commons.R.string.faq_2_text_commons
                )
            )
            faqItems.add(
                FAQItem(
                    org.fossify.commons.R.string.faq_6_title_commons,
                    org.fossify.commons.R.string.faq_6_text_commons
                )
            )
        }

        startAboutActivity(
            appNameId = R.string.app_name,
            licenseMask = licenses,
            versionName = BuildConfig.VERSION_NAME,
            faqItems = faqItems,
            showFAQBeforeMail = true
        )
    }

    private fun getLastPart(path: String): String {
        val humanized = humanizePath(path)
        return humanized.substringAfterLast("/", humanized)
    }

    private fun setupSound() = binding.apply {
        settingsSound.isChecked = config.isSoundEnabled
        settingsSoundHolder.setOnClickListener {
            settingsSound.toggle()
            config.isSoundEnabled = settingsSound.isChecked
        }
    }

    private fun setupVolumeButtonsAsShutter() = binding.apply {
        settingsVolumeButtonsAsShutter.isChecked = config.volumeButtonsAsShutter
        settingsVolumeButtonsAsShutterHolder.setOnClickListener {
            settingsVolumeButtonsAsShutter.toggle()
            config.volumeButtonsAsShutter = settingsVolumeButtonsAsShutter.isChecked
        }
    }

    private fun setupMaxBrightness() = binding.apply {
        settingsMaxBrightness.isChecked = config.maxBrightness
        settingsMaxBrightnessHolder.setOnClickListener {
            settingsMaxBrightness.toggle()
            config.maxBrightness = settingsMaxBrightness.isChecked
        }
    }

    private fun setupFlipPhotos() = binding.apply {
        settingsFlipPhotos.isChecked = config.flipPhotos
        settingsFlipPhotosHolder.setOnClickListener {
            settingsFlipPhotos.toggle()
            config.flipPhotos = settingsFlipPhotos.isChecked
        }
    }

    private fun setupSavePhotoMetadata() = binding.apply {
        settingsSavePhotoMetadata.isChecked = config.savePhotoMetadata
        settingsSavePhotoMetadataHolder.setOnClickListener {
            settingsSavePhotoMetadata.toggle()
            config.savePhotoMetadata = settingsSavePhotoMetadata.isChecked
        }
    }

    private fun setupSavePhotoVideoLocation() = binding.apply {
        settingsSavePhotoVideoLocation.isChecked = config.savePhotoVideoLocation
        settingsSavePhotoVideoLocationHolder.setOnClickListener {
            val willEnableSavePhotoVideoLocation = !config.savePhotoVideoLocation

            if (willEnableSavePhotoVideoLocation) {
                if (checkLocationPermission()) {
                    updateSavePhotoVideoLocationConfig(true)
                } else {
                    handlePermission(PERMISSION_ACCESS_FINE_LOCATION) { _ ->
                        if (checkLocationPermission()) {
                            updateSavePhotoVideoLocationConfig(true)
                        } else {
                            OpenDeviceSettingsDialog(
                                activity = this@SettingsActivity,
                                message = getString(org.fossify.commons.R.string.allow_location_permission)
                            )
                        }
                    }
                }
            } else {
                updateSavePhotoVideoLocationConfig(false)
            }
        }
    }

    private fun updateSavePhotoVideoLocationConfig(enabled: Boolean) {
        binding.settingsSavePhotoVideoLocation.isChecked = enabled
        config.savePhotoVideoLocation = enabled
    }

    private fun setupSavePhotosFolder() = binding.apply {
        settingsSavePhotosLabel.text = getString(R.string.save_photos)
        settingsSavePhotos.text = getLastPart(config.savePhotosFolder)
        settingsSavePhotosHolder.setOnClickListener {
            FilePickerDialog(
                this@SettingsActivity,
                config.savePhotosFolder,
                false,
                showFAB = true
            ) {
                val path = it
                handleSAFDialog(it) { success ->
                    if (success) {
                        config.savePhotosFolder = path
                        settingsSavePhotos.text = getLastPart(config.savePhotosFolder)
                    }
                }
            }
        }
    }

    private fun setupPhotoQuality() {
        updatePhotoQuality(config.photoQuality)
        binding.settingsPhotoQualityHolder.setOnClickListener {
            val items = arrayListOf(
                RadioItem(100, "100%"),
                RadioItem(95, "95%"),
                RadioItem(90, "90%"),
                RadioItem(85, "85%"),
                RadioItem(80, "80%"),
                RadioItem(75, "75%"),
                RadioItem(70, "70%"),
                RadioItem(65, "65%"),
                RadioItem(60, "60%"),
                RadioItem(55, "55%"),
                RadioItem(50, "50%")
            )

            RadioGroupDialog(this@SettingsActivity, items, config.photoQuality) {
                config.photoQuality = it as Int
                updatePhotoQuality(it)
            }
        }
    }

    @SuppressLint("SetTextI18n")
    private fun updatePhotoQuality(quality: Int) {
        binding.settingsPhotoQuality.text = "$quality%"
    }

    private fun setupCaptureMode() {
        updateCaptureMode(config.captureMode)
        binding.settingsCaptureModeHolder.setOnClickListener {
            val items = CaptureMode.values().mapIndexed { index, captureMode ->
                RadioItem(index, getString(captureMode.stringResId), captureMode)
            }

            RadioGroupDialog(this@SettingsActivity, ArrayList(items), config.captureMode.ordinal) {
                config.captureMode = it as CaptureMode
                updateCaptureMode(it)
            }
        }
    }

    private fun updateCaptureMode(captureMode: CaptureMode) {
        binding.settingsCaptureMode.text = getString(captureMode.stringResId)
    }

    private fun setupVideoFormat() {
        updateVideoFormat(config.videoFormat)
        binding.settingsVideoFormatHolder.setOnClickListener {
            val items = arrayListOf(
                RadioItem(Config.VIDEO_FORMAT_AUTO, getString(R.string.video_format_auto)),
                RadioItem(Config.VIDEO_FORMAT_HEVC, getString(R.string.video_format_hevc))
            )

            RadioGroupDialog(this@SettingsActivity, items, config.videoFormat) {
                config.videoFormat = it as Int
                updateVideoFormat(it)
            }
        }
    }

    private fun updateVideoFormat(format: Int) {
        binding.settingsVideoFormat.text = getString(
            if (format == Config.VIDEO_FORMAT_HEVC) R.string.video_format_hevc else R.string.video_format_auto
        )
    }

    private fun setupRememberLens() = binding.apply {
        settingsRememberLens.isChecked = config.rememberLens
        settingsRememberLensHolder.setOnClickListener {
            settingsRememberLens.toggle()
            config.rememberLens = settingsRememberLens.isChecked
        }
    }

    private fun setupGridLines() {
        updateGridLines(config.gridMode)
        binding.settingsGridHolder.setOnClickListener {
            val items = arrayListOf(
                RadioItem(0, getString(R.string.grid_off)),
                RadioItem(3, getString(R.string.grid_3x3)),
                RadioItem(4, getString(R.string.grid_4x4))
            )

            RadioGroupDialog(this@SettingsActivity, items, config.gridMode) {
                config.gridMode = it as Int
                updateGridLines(it)
            }
        }
    }

    private fun updateGridLines(mode: Int) {
        binding.settingsGrid.text = getString(
            when (mode) {
                3 -> R.string.grid_3x3
                4 -> R.string.grid_4x4
                else -> R.string.grid_off
            }
        )
    }

    private fun setupSwipeCamera() = binding.apply {
        settingsSwipeCamera.isChecked = config.swipeToSwitchCamera
        settingsSwipeCameraHolder.setOnClickListener {
            settingsSwipeCamera.toggle()
            config.swipeToSwitchCamera = settingsSwipeCamera.isChecked
        }
    }

    private fun setupPhotoFormat() {
        updatePhotoFormat(config.photoFormat)
        binding.settingsPhotoFormatHolder.setOnClickListener {
            val items = arrayListOf(
                RadioItem(Config.PHOTO_FORMAT_JPEG, getString(R.string.photo_format_jpeg)),
                RadioItem(Config.PHOTO_FORMAT_HEIC, getString(R.string.photo_format_heic))
            )

            RadioGroupDialog(this@SettingsActivity, items, config.photoFormat) {
                config.photoFormat = it as Int
                updatePhotoFormat(it)
            }
        }
    }

    private fun updatePhotoFormat(format: Int) {
        binding.settingsPhotoFormat.text = getString(
            if (format == Config.PHOTO_FORMAT_HEIC) R.string.photo_format_heic else R.string.photo_format_jpeg
        )
    }

    private fun setupHeicQuality() {
        updateHeicQuality(config.heicQuality)
        binding.settingsHeicQualityHolder.setOnClickListener {
            val items = arrayListOf(
                RadioItem(100, "100%"),
                RadioItem(90, "90%"),
                RadioItem(80, "80%")
            )

            RadioGroupDialog(this@SettingsActivity, items, config.heicQuality) {
                config.heicQuality = it as Int
                updateHeicQuality(it)
            }
        }
    }

    @SuppressLint("SetTextI18n")
    private fun updateHeicQuality(quality: Int) {
        binding.settingsHeicQuality.text = "$quality%"
    }

    private fun setupStartMax() = binding.apply {
        settingsStartMax.isChecked = config.startWithMaxFourThree
        settingsStartMaxHolder.setOnClickListener {
            settingsStartMax.toggle()
            config.startWithMaxFourThree = settingsStartMax.isChecked
        }
    }

    private fun setupQr() = binding.apply {
        settingsQr.isChecked = config.qrScanEnabled
        settingsQrHolder.setOnClickListener {
            settingsQr.toggle()
            config.qrScanEnabled = settingsQr.isChecked
        }
    }
}
