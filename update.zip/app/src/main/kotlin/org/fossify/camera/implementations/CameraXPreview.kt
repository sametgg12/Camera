package org.fossify.camera.implementations

import android.annotation.SuppressLint
import android.content.Context
import android.hardware.camera2.CameraCharacteristics
import android.hardware.SensorManager
import android.hardware.display.DisplayManager
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.util.Rational
import android.util.Size
import android.view.Display
import android.view.GestureDetector
import android.view.GestureDetector.SimpleOnGestureListener
import android.view.MotionEvent
import android.view.OrientationEventListener
import android.view.ScaleGestureDetector
import android.view.Surface
import androidx.annotation.OptIn
import androidx.camera.camera2.interop.Camera2CameraInfo
import androidx.camera.camera2.interop.ExperimentalCamera2Interop
import androidx.camera.core.Camera
import androidx.camera.core.CameraInfo
import androidx.camera.core.CameraSelector
import androidx.camera.core.CameraState
import androidx.camera.core.DisplayOrientedMeteringPointFactory
import androidx.camera.core.FocusMeteringAction
import androidx.camera.core.ImageAnalysis
import androidx.camera.core.ImageCapture
import androidx.camera.core.ImageCapture.Builder
import androidx.camera.core.ImageCapture.CAPTURE_MODE_MAXIMIZE_QUALITY
import androidx.camera.core.ImageCapture.CAPTURE_MODE_MINIMIZE_LATENCY
import androidx.camera.core.ImageCapture.ERROR_CAPTURE_FAILED
import androidx.camera.core.ImageCapture.FLASH_MODE_AUTO
import androidx.camera.core.ImageCapture.FLASH_MODE_OFF
import androidx.camera.core.ImageCapture.FLASH_MODE_ON
import androidx.camera.core.ImageCapture.Metadata
import androidx.camera.core.ImageCapture.OnImageCapturedCallback
import androidx.camera.core.ImageCaptureException
import androidx.camera.core.ImageProxy
import androidx.camera.core.Preview
import androidx.camera.core.UseCase
import androidx.camera.core.UseCaseGroup
import androidx.camera.core.ViewPort
import androidx.camera.core.resolutionselector.ResolutionSelector
import androidx.camera.core.resolutionselector.ResolutionSelector.PREFER_CAPTURE_RATE_OVER_HIGHER_RESOLUTION
import androidx.camera.core.resolutionselector.ResolutionSelector.PREFER_HIGHER_RESOLUTION_OVER_CAPTURE_RATE
import androidx.camera.core.resolutionselector.ResolutionStrategy
import androidx.camera.core.resolutionselector.ResolutionStrategy.FALLBACK_RULE_CLOSEST_LOWER_THEN_HIGHER
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.video.FallbackStrategy
import androidx.camera.video.FileDescriptorOutputOptions
import androidx.camera.video.FileOutputOptions
import androidx.camera.video.MediaStoreOutputOptions
import androidx.camera.video.Quality
import androidx.camera.video.QualitySelector
import androidx.camera.video.Recorder
import androidx.camera.video.Recording
import androidx.camera.video.VideoCapture
import androidx.camera.video.VideoRecordEvent
import androidx.camera.view.PreviewView
import androidx.camera.view.PreviewView.ScaleType
import androidx.core.content.ContextCompat
import androidx.core.view.doOnLayout
import androidx.lifecycle.DefaultLifecycleObserver
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleOwner
import androidx.window.layout.WindowMetricsCalculator
import com.bumptech.glide.load.ImageHeaderParser.UNKNOWN_ORIENTATION
import org.fossify.camera.R
import org.fossify.camera.extensions.checkLocationPermission
import org.fossify.camera.extensions.config
import org.fossify.camera.extensions.toAppFlashMode
import org.fossify.camera.extensions.toCameraSelector
import org.fossify.camera.extensions.toCameraXFlashMode
import org.fossify.camera.extensions.toCameraXQuality
import org.fossify.camera.extensions.toLensFacing
import org.fossify.camera.helpers.BitmapUtils
import org.fossify.camera.helpers.CameraErrorHandler
import org.fossify.camera.helpers.Config
import org.fossify.camera.helpers.FLASH_ALWAYS_ON
import org.fossify.camera.helpers.FLASH_ON
import org.fossify.camera.helpers.ImageQualityManager
import org.fossify.camera.helpers.ImageSaver
import org.fossify.camera.helpers.ImageUtil
import org.fossify.camera.helpers.MediaOutputHelper
import org.fossify.camera.helpers.MediaSizeStore
import org.fossify.camera.helpers.MediaSoundHelper
import org.fossify.camera.helpers.SimpleLocationManager
import org.fossify.camera.helpers.VideoQualityManager
import org.fossify.camera.interfaces.MyPreview
import org.fossify.camera.models.CaptureMode
import org.fossify.camera.models.MediaOutput
import org.fossify.camera.models.MySize
import org.fossify.camera.models.ResolutionOption
import org.fossify.commons.activities.BaseSimpleActivity
import org.fossify.commons.extensions.toast
import org.fossify.commons.helpers.PERMISSION_ACCESS_FINE_LOCATION
import org.fossify.commons.helpers.ensureBackgroundThread
import java.util.Locale
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors
import zxingcpp.BarcodeReader
import kotlin.math.abs
import kotlin.math.hypot
import kotlin.math.roundToInt

class CameraXPreview(
    private val activity: BaseSimpleActivity,
    private val previewView: PreviewView,
    private val mediaSoundHelper: MediaSoundHelper,
    private val mediaOutputHelper: MediaOutputHelper,
    private val cameraErrorHandler: CameraErrorHandler,
    private val listener: CameraXPreviewListener,
    private val isThirdPartyIntent: Boolean,
    initInPhotoMode: Boolean,
) : MyPreview, DefaultLifecycleObserver {

    companion object {
        // Auto focus is 1/6 of the area.
        private const val AF_SIZE = 1.0f / 6.0f
        private const val AE_SIZE = AF_SIZE * 1.5f
        private const val CAMERA_MODE_SWITCH_WAIT_TIME = 500L

        // Diagonal of a full frame (35mm) sensor, used to compare focal lengths of different lenses.
        private const val FULL_FRAME_DIAGONAL_MM = 43.27f
        private const val WIDE_LENS_MAX_RATIO = 0.85f
        private const val TELE_LENS_MIN_RATIO = 1.5f

        // How much the user has to pinch in at minimum zoom before we switch to a wider lens.
        private const val LENS_SWITCH_PINCH_THRESHOLD = 0.9f
        private const val ZOOM_EPSILON = 0.01f
        private const val MIME_HEVC = "video/hevc"
        private const val SWIPE_MIN_DISTANCE_DP = 120f
        private const val SWIPE_MIN_VELOCITY = 800f
        private const val QR_SCAN_INTERVAL_MS = 300L
        private const val QR_ANALYSIS_WIDTH = 1280
        private const val QR_ANALYSIS_HEIGHT = 720
        private const val PHOTO_JPEG_QUALITY_FOR_HEIC = 100
    }

    private val config = activity.config
    private val contentResolver = activity.contentResolver
    private val mainExecutor = ContextCompat.getMainExecutor(activity)
    private val displayManager =
        activity.getSystemService(Context.DISPLAY_SERVICE) as DisplayManager
    private val windowMetricsCalculator = WindowMetricsCalculator.getOrCreate()
    private val videoQualityManager = VideoQualityManager(activity)
    private val imageQualityManager = ImageQualityManager(activity)
    private val mediaSizeStore = MediaSizeStore(config)

    private val orientationEventListener =
        object : OrientationEventListener(activity, SensorManager.SENSOR_DELAY_NORMAL) {
            @SuppressLint("RestrictedApi")
            override fun onOrientationChanged(orientation: Int) {
                if (orientation == UNKNOWN_ORIENTATION) {
                    return
                }

                val rotation = when (orientation) {
                    in 45 until 135 -> Surface.ROTATION_270
                    in 135 until 225 -> Surface.ROTATION_180
                    in 225 until 315 -> Surface.ROTATION_90
                    else -> Surface.ROTATION_0
                }

                if (lastRotation != rotation) {
                    preview?.targetRotation = rotation
                    imageCapture?.targetRotation = rotation
                    videoCapture?.targetRotation = rotation
                    lastRotation = rotation
                }
            }
        }
    private val cameraHandler = Handler(Looper.getMainLooper())
    private val photoModeRunnable = Runnable {
        if (imageCapture == null) {
            isPhotoCapture = true
            if (!isThirdPartyIntent) { // we don't want to store the state for 3rd party intents
                config.initPhotoMode = true
            }
            startCamera()
        } else {
            listener.onInitPhotoMode()
        }
    }
    private val videoModeRunnable = Runnable {
        if (videoCapture == null) {
            isPhotoCapture = false
            if (!isThirdPartyIntent) { // we don't want to store the state for 3rd party intents
                config.initPhotoMode = false
            }
            startCamera()
        } else {
            listener.onInitVideoMode()
        }
    }

    private var preview: Preview? = null
    private var cameraProvider: ProcessCameraProvider? = null
    private var imageCapture: ImageCapture? = null
    private var videoCapture: VideoCapture<Recorder>? = null
    private var hevcUnsupported = false
    private var qrExecutor: ExecutorService? = null
    private var qrReader: BarcodeReader? = null
    private var lastQrScanTime = 0L
    private var camera: Camera? = null
    private var currentRecording: Recording? = null
    private var recordingState: VideoRecordEvent? = null
    private var cameraSelector = config.lastUsedCameraLens.toCameraSelector()
    private var backLenses: List<BackLens> = emptyList()
    private var mainBackCameraId: String? = null
    private var selectedLensId: String? = null
    private var lensSwitchInProgress = false
    private var flashMode = FLASH_MODE_OFF
    private var isPhotoCapture = initInPhotoMode
    private var lastRotation = 0
    private var lastCameraStartTime = 0L
    private var simpleLocationManager: SimpleLocationManager? = null

    init {
        bindToLifeCycle()
    }

    private fun bindToLifeCycle() {
        activity.lifecycle.addObserver(this)
    }

    private fun startCamera(switching: Boolean = false) {
        val cameraProviderFuture = ProcessCameraProvider.getInstance(activity.applicationContext)
        cameraProviderFuture.addListener({
            try {
                val provider = cameraProviderFuture.get()
                cameraProvider = provider
                imageQualityManager.initSupportedQualities()
                videoQualityManager.initSupportedQualities(provider)
                updateBackLenses(provider)
                bindCameraUseCases()
                setupCameraObservers()
            } catch (e: Exception) {
                if (e is IllegalArgumentException && !isPhotoCapture && !hevcUnsupported &&
                    config.videoFormat == Config.VIDEO_FORMAT_HEVC
                ) {
                    hevcUnsupported = true
                    activity.toast(R.string.hevc_not_supported)
                    startCamera(switching)
                    return@addListener
                }
                lensSwitchInProgress = false
                val errorMessage =
                    if (switching) R.string.camera_switch_error else R.string.camera_open_error
                activity.toast(errorMessage)
            }
        }, mainExecutor)
    }

    private fun bindCameraUseCases() {
        val cameraProvider =
            cameraProvider ?: throw IllegalStateException("Camera initialization failed.")

        val resolution = if (isPhotoCapture) {
            imageQualityManager.getUserSelectedResolution(cameraSelector).also {
                listener.displaySelectedResolution(it.toResolutionOption())
            }
        } else {
            val selectedQuality = videoQualityManager.getUserSelectedQuality(cameraSelector).also {
                listener.displaySelectedResolution(it.toResolutionOption())
            }
            MySize(selectedQuality.width, selectedQuality.height)
        }

        listener.adjustPreviewView(resolution.requiresCentering())

        val isFullSize = resolution.isFullScreen
        previewView.scaleType = if (isFullSize) ScaleType.FILL_CENTER else ScaleType.FIT_CENTER
        val rotation = previewView.display.rotation
        val targetResolution = Size(resolution.width, resolution.height)

        val previewUseCase = buildPreview(targetResolution, rotation)
        val captureUseCase = getCaptureUseCase(targetResolution, rotation)
        val analysisUseCase = if (isPhotoCapture && config.qrScanEnabled) buildQrAnalysis() else null

        val bindSelector = getBindSelector()
        cameraProvider.unbindAll()
        camera = if (isFullSize) {
            val metrics = windowMetricsCalculator.computeCurrentWindowMetrics(activity).bounds
            val screenWidth = metrics.width()
            val screenHeight = metrics.height()
            val viewPort = ViewPort.Builder(Rational(screenWidth, screenHeight), rotation).build()

            val useCaseGroup = UseCaseGroup.Builder()
                .addUseCase(previewUseCase)
                .addUseCase(captureUseCase)
                .apply { analysisUseCase?.let { addUseCase(it) } }
                .setViewPort(viewPort)
                .build()

            cameraProvider.bindToLifecycle(
                activity,
                bindSelector,
                useCaseGroup,
            )
        } else {
            val useCases = listOfNotNull(previewUseCase, captureUseCase, analysisUseCase)
            cameraProvider.bindToLifecycle(
                activity,
                bindSelector,
                *useCases.toTypedArray(),
            )
        }
        preview = previewUseCase
        setupZoomAndFocus()
        setFlashlightState(config.flashlightState)
    }

    private fun buildQrAnalysis(): ImageAnalysis {
        val executor = qrExecutor ?: Executors.newSingleThreadExecutor().also { qrExecutor = it }
        val reader = qrReader ?: BarcodeReader().also { qrReader = it }
        val resolutionSelector = ResolutionSelector.Builder()
            .setResolutionStrategy(
                ResolutionStrategy(
                    Size(QR_ANALYSIS_WIDTH, QR_ANALYSIS_HEIGHT),
                    FALLBACK_RULE_CLOSEST_LOWER_THEN_HIGHER
                )
            )
            .build()

        return ImageAnalysis.Builder()
            .setResolutionSelector(resolutionSelector)
            .setBackpressureStrategy(ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST)
            .build().also { analysis ->
                analysis.setAnalyzer(executor) { frame ->
                    val now = SystemClock.elapsedRealtime()
                    if (now - lastQrScanTime < QR_SCAN_INTERVAL_MS) {
                        frame.close()
                        return@setAnalyzer
                    }
                    lastQrScanTime = now
                    try {
                        val text = frame.use { reader.read(it) }
                            .firstOrNull { it.format.toString().contains("QR", ignoreCase = true) }
                            ?.text
                        if (!text.isNullOrEmpty()) {
                            mainExecutor.execute { listener.onQrCodeFound(text) }
                        }
                    } catch (e: Exception) {
                        // Ignore frames that cannot be decoded.
                    }
                }
            }
    }

    private fun buildPreview(resolution: Size, rotation: Int): Preview {
        return Preview.Builder()
            .setTargetRotation(rotation)
            .setResolutionSelector(getResolutionSelector(resolution))
            .build().apply {
                setSurfaceProvider(previewView.surfaceProvider)
            }
    }

    private fun getCaptureUseCase(resolution: Size, rotation: Int): UseCase {
        return if (isPhotoCapture) {
            buildImageCapture(resolution, rotation).also {
                imageCapture = it
                videoCapture = null
            }
        } else {
            buildVideoCapture().also {
                videoCapture = it
                imageCapture = null
            }
        }
    }

    private fun buildImageCapture(resolution: Size, rotation: Int): ImageCapture {
        return Builder()
            .setCaptureMode(getCaptureMode())
            .setFlashMode(flashMode)
            .setJpegQuality(if (mediaOutputHelper.isHeicEnabled()) PHOTO_JPEG_QUALITY_FOR_HEIC else config.photoQuality)
            .setTargetRotation(rotation)
            .setResolutionSelector(getResolutionSelector(resolution))
            .build()
    }

    private fun getCaptureMode(): Int {
        return when (config.captureMode) {
            CaptureMode.MINIMIZE_LATENCY -> CAPTURE_MODE_MINIMIZE_LATENCY
            CaptureMode.MAXIMIZE_QUALITY -> CAPTURE_MODE_MAXIMIZE_QUALITY
        }
    }

    private fun getResolutionSelector(resolution: Size): ResolutionSelector {
        return ResolutionSelector.Builder()
            .setResolutionStrategy(ResolutionStrategy(resolution, FALLBACK_RULE_CLOSEST_LOWER_THEN_HIGHER))
            .setResolutionFilter { supportedSizes, rotationDegrees ->
                // Sort by closest image ratio
                supportedSizes.sortedBy {
                    size -> abs(size.width / size.height.toFloat() - resolution.width / resolution.height.toFloat())
                }
            }
            .setAllowedResolutionMode(getAllowedResolutionMode())
            .build()
    }

    private fun getAllowedResolutionMode(): Int {
        return when (config.captureMode) {
            CaptureMode.MINIMIZE_LATENCY -> PREFER_CAPTURE_RATE_OVER_HIGHER_RESOLUTION
            CaptureMode.MAXIMIZE_QUALITY -> PREFER_HIGHER_RESOLUTION_OVER_CAPTURE_RATE
        }
    }

    private fun buildVideoCapture(): VideoCapture<Recorder> {
        val qualitySelector = QualitySelector.from(
            videoQualityManager.getUserSelectedQuality(cameraSelector).toCameraXQuality(),
            FallbackStrategy.higherQualityOrLowerThan(Quality.SD),
        )

        val recorderBuilder = Recorder.Builder().setQualitySelector(qualitySelector)
        if (config.videoFormat == Config.VIDEO_FORMAT_HEVC && !hevcUnsupported) {
            recorderBuilder.setVideoMimeType(MIME_HEVC)
        }
        val recorder = recorderBuilder.build()

        return VideoCapture.withOutput(recorder)
    }

    private fun setupCameraObservers() {
        lensSwitchInProgress = false
        listener.setFlashAvailable(camera?.cameraInfo?.hasFlashUnit() ?: false)
        listener.onChangeCamera(isFrontCameraInUse())
        listener.onLensesChanged(
            labels = if (isFrontCameraInUse()) emptyList() else backLenses.map { it.label },
            selectedIndex = currentLensIndex()
        )
        camera?.cameraInfo?.zoomState?.observe(activity) { zoomState ->
            val displayRatio = currentLensBaseRatio() * zoomState.zoomRatio
            listener.onZoomLabelChanged(formatZoomLabel(displayRatio))
        }
        if (isPhotoCapture) {
            listener.onInitPhotoMode()
        } else {
            listener.onInitVideoMode()
        }
        camera?.cameraInfo?.cameraState?.observe(activity) { cameraState ->
            if (cameraState.error == null) {
                when (cameraState.type) {
                    CameraState.Type.OPENING,
                    CameraState.Type.OPEN -> {
                        listener.setHasFrontAndBackCamera(hasFrontCamera() && hasBackCamera())
                        listener.setCameraAvailable(true)
                    }

                    CameraState.Type.PENDING_OPEN,
                    CameraState.Type.CLOSING,
                    CameraState.Type.CLOSED -> {
                        listener.setCameraAvailable(false)
                    }
                }
            } else {
                listener.setCameraAvailable(false)
                cameraErrorHandler.handleCameraError(cameraState.error)
            }
        }
    }

    private fun hasBackCamera(): Boolean {
        return cameraProvider?.hasCamera(CameraSelector.DEFAULT_BACK_CAMERA) ?: false
    }

    private fun hasFrontCamera(): Boolean {
        return cameraProvider?.hasCamera(CameraSelector.DEFAULT_FRONT_CAMERA) ?: false
    }

    private fun isFrontCameraInUse(): Boolean {
        return cameraSelector == CameraSelector.DEFAULT_FRONT_CAMERA
    }

    @SuppressLint("ClickableViewAccessibility")
    // source: https://stackoverflow.com/a/60095886/10552591
    private fun setupZoomAndFocus() {
        val scaleGesture = camera?.let {
            ScaleGestureDetector(activity, LensAwareZoomListener())
        }
        val gestureDetector = GestureDetector(activity, object : SimpleOnGestureListener() {
            override fun onDown(event: MotionEvent): Boolean {
                listener.onTouchPreview()
                return super.onDown(event)
            }

            override fun onFling(
                e1: MotionEvent?,
                e2: MotionEvent,
                velocityX: Float,
                velocityY: Float,
            ): Boolean {
                if (!config.swipeToSwitchCamera || e1 == null || scaleGesture?.isInProgress == true ||
                    e2.pointerCount > 1 || isRecordingNow() || lensSwitchInProgress ||
                    !hasFrontCamera() || !hasBackCamera()
                ) {
                    return false
                }
                val dx = e2.x - e1.x
                val dy = e2.y - e1.y
                val minDistance = SWIPE_MIN_DISTANCE_DP * activity.resources.displayMetrics.density
                if (abs(dy) > minDistance && abs(dy) > abs(dx) * 2 && abs(velocityY) > SWIPE_MIN_VELOCITY) {
                    toggleFrontBackCamera()
                    return true
                }
                return false
            }

            override fun onSingleTapConfirmed(event: MotionEvent): Boolean {
                return camera?.cameraInfo?.let {
                    val display = displayManager.getDisplay(Display.DEFAULT_DISPLAY)
                    val width = previewView.width.toFloat()
                    val height = previewView.height.toFloat()
                    val factory = DisplayOrientedMeteringPointFactory(display, it, width, height)
                    val xPos = event.x
                    val yPos = event.y
                    val autoFocusPoint = factory.createPoint(xPos, yPos, AF_SIZE)
                    val autoExposurePoint = factory.createPoint(xPos, yPos, AE_SIZE)
                    val focusMeteringAction =
                        FocusMeteringAction.Builder(autoFocusPoint, FocusMeteringAction.FLAG_AF)
                            .addPoint(autoExposurePoint, FocusMeteringAction.FLAG_AE)
                            .disableAutoCancel()
                            .build()
                    camera?.cameraControl?.startFocusAndMetering(focusMeteringAction)
                    listener.onFocusCamera(event.rawX, event.rawY)
                    true
                } ?: false
            }
        })
        previewView.setOnTouchListener { _, event ->
            val handledGesture = gestureDetector.onTouchEvent(event)
            val handledScaleGesture = scaleGesture?.onTouchEvent(event)
            handledGesture || handledScaleGesture ?: false
        }
    }

    override fun onStart(owner: LifecycleOwner) {
        orientationEventListener.enable()
        previewView.doOnLayout {
            if (owner.lifecycle.currentState.isAtLeast(Lifecycle.State.STARTED)) {
                startCamera()
            }
        }
    }

    override fun onResume(owner: LifecycleOwner) {
        super.onResume(owner)
        if (config.savePhotoVideoLocation) {
            if (simpleLocationManager == null) {
                simpleLocationManager = SimpleLocationManager(activity)
            }
            requestLocationUpdates()
        }
    }

    private fun requestLocationUpdates() {
        activity.apply {
            if (checkLocationPermission()) {
                simpleLocationManager?.requestLocationUpdates()
            } else {
                handlePermission(PERMISSION_ACCESS_FINE_LOCATION) { _ ->
                    if (checkLocationPermission()) {
                        simpleLocationManager?.requestLocationUpdates()
                    } else {
                        config.savePhotoVideoLocation = false
                    }
                }
            }
        }
    }

    override fun onPause(owner: LifecycleOwner) {
        super.onPause(owner)
        simpleLocationManager?.dropLocationUpdates()
    }

    override fun onStop(owner: LifecycleOwner) {
        orientationEventListener.disable()
    }

    override fun isInPhotoMode(): Boolean {
        return isPhotoCapture
    }

    override fun showChangeResolution() {
        val selectedResolution = if (isPhotoCapture) {
            imageQualityManager.getUserSelectedResolution(cameraSelector).toResolutionOption()
        } else {
            videoQualityManager.getUserSelectedQuality(cameraSelector).toResolutionOption()
        }

        val resolutions = if (isPhotoCapture) {
            imageQualityManager.getSupportedResolutions(cameraSelector)
                .map { it.toResolutionOption() }
        } else {
            videoQualityManager.getSupportedQualities(cameraSelector)
                .map { it.toResolutionOption() }
        }

        if (resolutions.size > 2) {
            listener.showImageSizes(
                selectedResolution = selectedResolution,
                resolutions = resolutions,
                isPhotoCapture = isPhotoCapture,
                isFrontCamera = isFrontCameraInUse()
            ) { index, changed ->
                mediaSizeStore.storeSize(isPhotoCapture, isFrontCameraInUse(), index)
                if (changed) {
                    currentRecording?.stop()
                    startCamera()
                }
            }
        } else {
            toggleResolutions(resolutions)
        }
    }

    private fun toggleResolutions(resolutions: List<ResolutionOption>) {
        if (resolutions.size >= 2) {
            val currentIndex =
                mediaSizeStore.getCurrentSizeIndex(isPhotoCapture, isFrontCameraInUse())

            val nextIndex = if (currentIndex >= resolutions.lastIndex) {
                0
            } else {
                currentIndex + 1
            }

            mediaSizeStore.storeSize(isPhotoCapture, isFrontCameraInUse(), nextIndex)
            currentRecording?.stop()
            startCamera()
        }
    }

    private fun getBindSelector(): CameraSelector {
        val lensId = selectedLensId
        if (isFrontCameraInUse() || lensId == null || lensId == mainBackCameraId) {
            return cameraSelector
        }
        return buildSelectorForCameraId(lensId)
    }

    @OptIn(ExperimentalCamera2Interop::class)
    private fun buildSelectorForCameraId(cameraId: String): CameraSelector {
        return CameraSelector.Builder()
            .requireLensFacing(CameraSelector.LENS_FACING_BACK)
            .addCameraFilter { cameraInfos ->
                cameraInfos.filter { Camera2CameraInfo.from(it).cameraId == cameraId }
            }
            .build()
    }

    /**
     * Finds the usable back lenses (main + ultra wide / telephoto) and labels them
     * relative to the main lens, e.g. 0.5x, 1x. Macro and depth sensors are skipped
     * because their focal length is close to the main lens.
     */
    @OptIn(ExperimentalCamera2Interop::class)
    private fun updateBackLenses(provider: ProcessCameraProvider) {
        backLenses = emptyList()
        mainBackCameraId = null
        try {
            val allInfos = provider.availableCameraInfos
            val backInfos = allInfos.filter { it.lensFacing == CameraSelector.LENS_FACING_BACK }
            val mainInfo = CameraSelector.DEFAULT_BACK_CAMERA.filter(allInfos).firstOrNull()
                ?: backInfos.firstOrNull()
                ?: return
            val mainId = Camera2CameraInfo.from(mainInfo).cameraId
            val mainFocal = getEquivalentFocalLength(mainInfo) ?: return
            mainBackCameraId = mainId

            val lenses = backInfos.mapNotNull { info ->
                val id = Camera2CameraInfo.from(info).cameraId
                val ratio = (getEquivalentFocalLength(info) ?: return@mapNotNull null) / mainFocal
                val include = id == mainId || ratio < WIDE_LENS_MAX_RATIO || ratio > TELE_LENS_MIN_RATIO
                if (include) Triple(id, if (id == mainId) 1f else ratio, ratio) else null
            }.sortedBy { it.second }

            if (lenses.size < 2) {
                return
            }

            backLenses = lenses.map { (id, displayRatio, _) ->
                BackLens(id, formatZoomLabel(displayRatio), displayRatio)
            }
            if (selectedLensId == null && config.rememberLens) {
                selectedLensId = config.lastBackLensId.ifEmpty { null }
            }
            if (backLenses.none { it.cameraId == selectedLensId }) {
                selectedLensId = mainId
            }
        } catch (e: Exception) {
            backLenses = emptyList()
            selectedLensId = null
        }
    }

    @OptIn(ExperimentalCamera2Interop::class)
    private fun getEquivalentFocalLength(info: CameraInfo): Float? {
        val camera2Info = Camera2CameraInfo.from(info)
        val focalLength = camera2Info
            .getCameraCharacteristic(CameraCharacteristics.LENS_INFO_AVAILABLE_FOCAL_LENGTHS)
            ?.firstOrNull() ?: return null
        val sensorSize = camera2Info
            .getCameraCharacteristic(CameraCharacteristics.SENSOR_INFO_PHYSICAL_SIZE) ?: return null
        val diagonal = hypot(sensorSize.width, sensorSize.height)
        if (diagonal <= 0f) {
            return null
        }
        return focalLength * FULL_FRAME_DIAGONAL_MM / diagonal
    }

    private fun formatZoomLabel(ratio: Float): String {
        val rounded = (ratio * 10).roundToInt() / 10f
        return String.format(Locale.US, "%.1f", rounded).removeSuffix(".0") + "x"
    }

    private fun currentLensIndex(): Int {
        val id = selectedLensId ?: mainBackCameraId
        return backLenses.indexOfFirst { it.cameraId == id }.coerceAtLeast(0)
    }

    private fun isRecordingNow(): Boolean {
        return currentRecording != null && recordingState !is VideoRecordEvent.Finalize
    }

    private fun canSwitchLens(): Boolean {
        return !isFrontCameraInUse() && backLenses.size >= 2 && !isRecordingNow() && !lensSwitchInProgress
    }

    private fun currentLensBaseRatio(): Float {
        return backLenses.getOrNull(currentLensIndex())?.ratio ?: 1f
    }

    private fun switchToLens(lens: BackLens) {
        lensSwitchInProgress = true
        selectedLensId = lens.cameraId
        config.lastBackLensId = lens.cameraId
        startCamera(switching = true)
    }

    fun cycleBackLens() {
        if (!canSwitchLens()) {
            return
        }
        switchToLens(backLenses[(currentLensIndex() + 1) % backLenses.size])
    }

    /**
     * Pinch to zoom that also moves between lenses: pinching in at minimum zoom switches to the
     * next wider lens, and zooming in past the next lens' ratio switches to that lens.
     */
    private inner class LensAwareZoomListener : ScaleGestureDetector.SimpleOnScaleGestureListener() {
        private var accumulatedScale = 1f

        // The zoom ratio we asked the camera for. CameraX reports the real value asynchronously,
        // so reading it on every pinch event made the zoom lag behind the fingers.
        private var targetZoom = 1f
        private var trackedCamera: Camera? = null

        override fun onScaleBegin(detector: ScaleGestureDetector): Boolean {
            accumulatedScale = 1f
            val currentCamera = camera
            trackedCamera = currentCamera
            targetZoom = currentCamera?.cameraInfo?.zoomState?.value?.zoomRatio ?: 1f
            return true
        }

        override fun onScale(detector: ScaleGestureDetector): Boolean {
            val currentCamera = camera ?: return false
            val zoomState = currentCamera.cameraInfo.zoomState.value ?: return false
            if (lensSwitchInProgress) {
                return true
            }

            if (trackedCamera !== currentCamera) {
                trackedCamera = currentCamera
                targetZoom = zoomState.zoomRatio
            }

            val scale = detector.scaleFactor
            val index = currentLensIndex()
            val minZoom = zoomState.minZoomRatio
            val maxZoom = zoomState.maxZoomRatio
            val atMinZoom = targetZoom <= minZoom + ZOOM_EPSILON

            if (canSwitchLens() && atMinZoom) {
                if (scale < 1f) {
                    accumulatedScale *= scale
                    val widerLens = backLenses.getOrNull(index - 1)
                    if (widerLens != null && accumulatedScale < LENS_SWITCH_PINCH_THRESHOLD) {
                        accumulatedScale = 1f
                        switchToLens(widerLens)
                        return true
                    }
                } else {
                    accumulatedScale = 1f
                }
            }

            val rawRatio = targetZoom * scale
            if (canSwitchLens()) {
                val nextLens = backLenses.getOrNull(index + 1)
                if (nextLens != null && currentLensBaseRatio() * rawRatio >= nextLens.ratio) {
                    switchToLens(nextLens)
                    return true
                }
            }

            targetZoom = rawRatio.coerceIn(minZoom, maxZoom)
            currentCamera.cameraControl.setZoomRatio(targetZoom)
            return true
        }
    }

    override fun toggleFrontBackCamera() {
        val newCameraSelector = if (isFrontCameraInUse()) {
            CameraSelector.DEFAULT_BACK_CAMERA
        } else {
            CameraSelector.DEFAULT_FRONT_CAMERA
        }

        cameraSelector = newCameraSelector
        config.lastUsedCameraLens = newCameraSelector.toLensFacing()
        startCamera(switching = true)
    }

    override fun handleFlashlightClick() {
        if (isPhotoCapture) {
            listener.showFlashOptions(true)
        } else {
            toggleFlashlight()
        }
    }

    private fun toggleFlashlight() {
        val newFlashMode = if (isPhotoCapture) {
            when (flashMode) {
                FLASH_MODE_OFF -> FLASH_MODE_ON
                FLASH_MODE_ON -> FLASH_MODE_AUTO
                else -> FLASH_MODE_OFF
            }
        } else {
            when (flashMode) {
                FLASH_MODE_OFF -> FLASH_MODE_ON
                else -> FLASH_MODE_OFF
            }
        }
        setFlashlightState(newFlashMode.toAppFlashMode())
    }

    override fun setFlashlightState(state: Int) {
        var flashState = state
        if (isPhotoCapture) {
            camera?.cameraControl?.enableTorch(flashState == FLASH_ALWAYS_ON)
        } else {
            camera?.cameraControl?.enableTorch(flashState == FLASH_ON || flashState == FLASH_ALWAYS_ON)
            // reset to the FLASH_ON for video capture
            if (flashState == FLASH_ALWAYS_ON) {
                flashState = FLASH_ON
            }
        }
        val newFlashMode = flashState.toCameraXFlashMode()
        flashMode = newFlashMode
        imageCapture?.flashMode = newFlashMode

        config.flashlightState = flashState
        listener.onChangeFlashMode(flashState)
    }

    override fun tryTakePicture() {
        if (imageCapture == null) {
            activity.toast(R.string.camera_open_error)
            return
        }

        val imageCapture = imageCapture

        val metadata = Metadata().apply {
            isReversedHorizontal = isFrontCameraInUse() && config.flipPhotos
            if (config.savePhotoVideoLocation) {
                location = simpleLocationManager?.getLocation()
            }
        }

        val mediaOutput = mediaOutputHelper.getImageMediaOutput()
        val heicQuality = if (mediaOutputHelper.isHeicEnabled()) config.heicQuality else null
        imageCapture!!.takePicture(mainExecutor, object : OnImageCapturedCallback() {
            override fun onCaptureSuccess(image: ImageProxy) {
                listener.shutterAnimation()
                playShutterSoundIfEnabled()
                ensureBackgroundThread {
                    image.use {
                        if (mediaOutput is MediaOutput.BitmapOutput) {
                            val imageBytes = ImageUtil.jpegImageToJpegByteArray(image)
                            val bitmap = BitmapUtils.makeBitmap(imageBytes)
                            activity.runOnUiThread {
                                listener.onPhotoCaptureEnd()
                                if (bitmap != null) {
                                    listener.onImageCaptured(bitmap)
                                } else {
                                    cameraErrorHandler.handleImageCaptureError(ERROR_CAPTURE_FAILED)
                                }
                            }
                        } else {
                            ImageSaver.saveImage(
                                contentResolver = contentResolver,
                                image = image,
                                mediaOutput = mediaOutput,
                                metadata = metadata,
                                jpegQuality = if (heicQuality != null) PHOTO_JPEG_QUALITY_FOR_HEIC else config.photoQuality,
                                saveExifAttributes = config.savePhotoMetadata,
                                heicQuality = heicQuality,
                                onImageSaved = { savedUri ->
                                    activity.runOnUiThread {
                                        listener.onPhotoCaptureEnd()
                                        listener.onMediaSaved(savedUri)
                                    }
                                },
                                onError = ::handleImageCaptureError
                            )
                        }
                    }
                }
            }

            override fun onError(exception: ImageCaptureException) {
                handleImageCaptureError(exception)
            }
        })
    }

    private fun handleImageCaptureError(exception: ImageCaptureException) {
        listener.onPhotoCaptureEnd()
        cameraErrorHandler.handleImageCaptureError(exception.imageCaptureError)
    }

    override fun initPhotoMode() {
        debounceChangeCameraMode(photoModeRunnable)
    }

    override fun initVideoMode() {
        debounceChangeCameraMode(videoModeRunnable)
    }

    private fun debounceChangeCameraMode(cameraModeRunnable: Runnable) {
        val currentTime = System.currentTimeMillis()
        if (currentTime - lastCameraStartTime > CAMERA_MODE_SWITCH_WAIT_TIME) {
            cameraModeRunnable.run()
        } else {
            cameraHandler.removeCallbacks(photoModeRunnable)
            cameraHandler.removeCallbacks(videoModeRunnable)
            cameraHandler.postDelayed(cameraModeRunnable, CAMERA_MODE_SWITCH_WAIT_TIME)
        }
        lastCameraStartTime = currentTime
    }

    override fun toggleRecording() {
        if (currentRecording == null || recordingState is VideoRecordEvent.Finalize) {
            if (config.isSoundEnabled) {
                mediaSoundHelper.playStartVideoRecordingSound(onPlayComplete = {
                    startRecording()
                })
                listener.onVideoRecordingStarted()
            } else {
                startRecording()
            }
        } else {
            currentRecording?.stop()
            currentRecording = null
        }
    }

    @SuppressLint("MissingPermission", "NewApi")
    private fun startRecording() {
        if (videoCapture == null) {
            activity.toast(R.string.camera_open_error)
            return
        }

        val videoCapture = videoCapture

        val recording = when (val mediaOutput = mediaOutputHelper.getVideoMediaOutput()) {
            is MediaOutput.FileDescriptorMediaOutput -> {
                FileDescriptorOutputOptions.Builder(mediaOutput.fileDescriptor).apply {
                    if (config.savePhotoVideoLocation) {
                        setLocation(simpleLocationManager?.getLocation())
                    }
                }.build().let { videoCapture!!.output.prepareRecording(activity, it) }
            }

            is MediaOutput.FileMediaOutput -> {
                FileOutputOptions.Builder(mediaOutput.file).apply {
                    if (config.savePhotoVideoLocation) {
                        setLocation(simpleLocationManager?.getLocation())
                    }
                }.build().let { videoCapture!!.output.prepareRecording(activity, it) }
            }

            is MediaOutput.MediaStoreOutput -> {
                MediaStoreOutputOptions.Builder(contentResolver, mediaOutput.contentUri).apply {
                    setContentValues(mediaOutput.contentValues)
                    if (config.savePhotoVideoLocation) {
                        setLocation(simpleLocationManager?.getLocation())
                    }
                }.build().let { videoCapture!!.output.prepareRecording(activity, it) }
            }
        }

        currentRecording = recording.withAudioEnabled()
            .start(mainExecutor) { recordEvent ->
                recordingState = recordEvent
                when (recordEvent) {
                    is VideoRecordEvent.Start -> {
                        listener.onVideoRecordingStarted()
                    }

                    is VideoRecordEvent.Status -> {
                        listener.onVideoDurationChanged(recordEvent.recordingStats.recordedDurationNanos)
                    }

                    is VideoRecordEvent.Finalize -> {
                        playStopVideoRecordingSoundIfEnabled()
                        listener.onVideoRecordingStopped()
                        if (recordEvent.hasError()) {
                            cameraErrorHandler.handleVideoRecordingError(recordEvent.error)
                        } else {
                            listener.onMediaSaved(recordEvent.outputResults.outputUri)
                        }
                    }
                }
            }
    }

    private fun playShutterSoundIfEnabled() {
        if (config.isSoundEnabled) {
            mediaSoundHelper.playShutterSound()
        }
    }

    private fun playStopVideoRecordingSoundIfEnabled() {
        if (config.isSoundEnabled) {
            mediaSoundHelper.playStopVideoRecordingSound()
        }
    }
}

private data class BackLens(val cameraId: String, val label: String, val ratio: Float)
